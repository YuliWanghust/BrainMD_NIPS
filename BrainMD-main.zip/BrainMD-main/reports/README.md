# BrainBench process code

To process the Brain radiology report for the VLM downstream task: 
- follow **1. Anonymize_brain_tumor_textual_info.py** to anonymize and extract impressions. 
- follow **2. Compare_visual_Results.py** to interpret results and get performance metrics
