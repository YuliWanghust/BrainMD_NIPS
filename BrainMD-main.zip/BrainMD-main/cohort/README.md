# Define BrainMD Cohort

To generate cohort from BrainMD dataset: 
- **1. Cohort definition.py** to define cohort for ultimate dataset
- **2. Anonmization.py** to link and anonymize reports, and filter cohort based on reports.
- **3. DICOM extraction.py** to extract dicom metadata and filter cohort based on DICOM files
